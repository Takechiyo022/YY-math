const list = document.getElementById("worksheet-list");
const status = document.getElementById("status");
const count = document.getElementById("count");

const fallbackIcons = ["📘", "✏️", "📐", "🧩", "📈", "🎲"];
function makeCard(item, index) {
  const card = document.createElement("article");
  card.className = "worksheet-card";

  const heading = document.createElement("div");
  heading.className = "card-heading";

  const icon = document.createElement("div");
  icon.className = "card-icon";
  icon.setAttribute("aria-hidden", "true");
  icon.textContent = item.icon || fallbackIcons[index % fallbackIcons.length];

  const titleWrap = document.createElement("div");
  titleWrap.className = "card-title";

  const category = document.createElement("span");
  category.className = "card-category";
  category.textContent = item.category || "数学";

  const title = document.createElement("h3");
  title.textContent = item.title || item.file || "問題プリント";

  titleWrap.append(category, title);
  heading.append(icon, titleWrap);

  const description = document.createElement("p");
  description.className = "card-description";
  description.textContent = item.description || "数学の問題にチャレンジしよう！";

  const actions = document.createElement("div");
  actions.className = "card-actions";

  const open = document.createElement("a");
  open.className = "action";
  open.textContent = "PDFを開く ↗";
  open.href = "worksheets/" + encodeURIComponent(item.file).replace(/%2F/g, "/");
  open.target = "_blank";
  open.rel = "noopener";

  const download = document.createElement("a");
  download.className = "action secondary";
  download.textContent = "保存する ↓";
  download.href = open.href;
  download.download = item.file || "";

  actions.append(open, download);
  card.append(heading, description, actions);
  return card;
}

async function loadWorksheets() {
  try {
    const response = await fetch("worksheets.json", { cache: "no-store" });
    if (!response.ok) throw new Error("worksheets.json が見つかりません");
    const worksheets = await response.json();
    if (!Array.isArray(worksheets)) throw new Error("一覧データの形式が正しくありません");

    list.replaceChildren();
    worksheets.forEach((item, index) => list.appendChild(makeCard(item, index)));
    count.textContent = `${worksheets.length}セット`;
    status.hidden = worksheets.length > 0;
    if (worksheets.length === 0) {
      status.hidden = false;
      status.textContent = "まだ問題が登録されていません。";
    }
  } catch (error) {
    count.textContent = "読み込みエラー";
    status.hidden = false;
    status.textContent = "問題一覧を読み込めませんでした。GitHub Pages上で開いているか、worksheets.json があるか確認してください。";
    console.error(error);
  }
}
loadWorksheets();
