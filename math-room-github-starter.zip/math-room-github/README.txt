数学部屋問題まとめ〜わいわいを添えて〜

ファイル構成
- index.html: ページ構造
- style.css: 黄色基調のデザイン・スマホ対応
- script.js: 問題カードを表示する処理
- worksheets.json: 問題一覧の設定
- worksheets/: PDFファイル

GitHub Pagesで公開する
1. GitHubでリポジトリを作る
2. このフォルダ内のファイル・フォルダをすべてアップロードする
3. Settings → Pages → Deploy from a branch → main / (root) を選んで保存する
4. 公開されたURLを開く

PDFを追加するとき
1. PDFを worksheets/ フォルダにアップロード
2. worksheets.json に項目を1つ追加（fileはPDFのファイル名と完全一致させる）
3. GitHub Pagesの更新後に一覧に表示される

重要:
GitHub Pagesだけでは、フォルダにPDFを追加しただけで自動的に一覧を作ることはできません。
このスターター版は、PDFと worksheets.json の両方を更新する方式です。
PDF追加だけで完全自動にするには、GitHub Actionsなどで一覧データを自動生成する設定が別途必要です。
ローカルで index.html を直接開くと fetch が制限されることがあるため、GitHub Pages上で確認してください。
